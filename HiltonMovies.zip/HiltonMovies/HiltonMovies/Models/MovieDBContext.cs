﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HiltonMovies.Models
{
    public class MovieDBContext: DbContext
    {
        // constructor
        public MovieDBContext(DbContextOptions<MovieDBContext> options) : base (options)
        {

        }

        public DbSet<Categories> categories { get; set; }
        public DbSet<MovieDatabase> movies { get; set; }

        protected override void OnModelCreating(ModelBuilder mb)
        {
            //seeds the categories database with categories, used in the movie database to identify categories
            mb.Entity<Categories>().HasData(
                new Categories { CategoryId = 1, CategoryName="Sci-fi"},
                new Categories { CategoryId = 2, CategoryName="Adventure"},
                new Categories { CategoryId = 3, CategoryName="Romantic Comedy"}
            );
            // seeds the database with the three movies found below when the model is created
            mb.Entity<MovieDatabase>().HasData(
                // great movies
                    new MovieDatabase
                    {
                       MovieId = 1,
                       CategoryId = 1,
                       Title = "Star Wars",
                       Year = 1977,
                       Director = "George Lucas",
                       Rating = "PG",
                       Edited = false,
                       LentTo = "Spencer Hilton",
                       Notes = "Give it back Professor!"
                    },
                    // hope the new one is great
                    new MovieDatabase
                    {
                        MovieId = 2,
                        CategoryId = 2,
                        Title = "Raiders of the Lost Ark",
                        Year = 1981,
                        Director = "Steven Spielberg",
                        Rating = "PG",
                        Edited = false,
                        LentTo = "",
                        Notes = ""
                    },
                    new MovieDatabase
                    {
                        MovieId = 3,
                        CategoryId = 2,
                        Title = "How to Lose a Guy in 10 Days",
                        Year = 2003,
                        Director = "Donald Petrie",
                        Rating = "PG-13",
                        Edited = false,
                        LentTo = "Hulk Hogan",
                        Notes = "Remember, Hulk is a softy"
                    }
                );
        }
    }
}
