﻿using HiltonMovies.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace HiltonMovies.Controllers
{
    public class HomeController : Controller
    {
        private MovieDBContext _movieContext { get; set; }

        // constructor, constructs model context
        public HomeController(MovieDBContext data)
        {
            _movieContext = data;
        }

        // returns the home page
        public IActionResult Index()
        {
            return View();
        }

        // returns the podcast info page
        public IActionResult Bacon()
        {
            return View();
        }

        // returns the page view for the new movie form
        [HttpGet]
        public IActionResult Movies()
        {
            ViewBag.Categories = _movieContext.categories.ToList();
            return View();
        }

        // posts the new movie entered by the user to the model database
        [HttpPost]
        public IActionResult Movies(MovieDatabase newMovie)
        {

            ViewBag.Categories = _movieContext.categories.ToList();

            //checks if the model is still valid, then adds the new movie. If not, it won't add the movie and will stop the user,
            //requiring correct inputs
            if (ModelState.IsValid)
            {
                _movieContext.Add(newMovie);
                _movieContext.SaveChanges();
                return View("Confirmation", newMovie);
            }
            else
            {
                ViewBag.Categories = _movieContext.categories.ToList();

                return View(newMovie);
            }

        }

        //displays the data in the model in a table, and includes the category names from the separate category table
        public IActionResult MovieTable ()
        {
            var table = _movieContext.movies.Include(x => x.Category).ToList();
            return View(table);
        }

        //These actions get the movie that was requested to edit, and then edit that record and save the changes to the database
        [HttpGet]
        public IActionResult Edit (int movieid)
        {
            //creates a viewbag that brings in the category names based on the category id passed
            ViewBag.Categories = _movieContext.categories.ToList();

            //grabs single movie to be edited, and returns it to the view to be edited on the new movies page
            var movie = _movieContext.movies.Single(x => x.MovieId == movieid);

            return View("Movies", movie);
        }
        [HttpPost]
        public IActionResult Edit (MovieDatabase movie)
        {
            _movieContext.Update(movie);
            _movieContext.SaveChanges();

            return RedirectToAction("MovieTable");
        }

        //These actions get the movie that was requested to delete, and then delete that record and save the changes to the database
        [HttpGet]
        public IActionResult Delete (int movieid)
        {
            // selects the movie given to the action based on the id delivered from the asp-route-movieid on the MovieTable page
            var movie = _movieContext.movies.Single(x => x.MovieId == movieid);
            return View(movie);
        }
        [HttpPost]
        public IActionResult Delete(MovieDatabase movie)
        {
            _movieContext.movies.Remove(movie);
            _movieContext.SaveChanges();

            //once the record is deleted, it sends the user back to the table page
            return RedirectToAction("MovieTable");
        }
    }
}
